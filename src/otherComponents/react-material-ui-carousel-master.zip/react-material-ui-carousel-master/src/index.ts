import Carousel from './components/Carousel';

export default Carousel